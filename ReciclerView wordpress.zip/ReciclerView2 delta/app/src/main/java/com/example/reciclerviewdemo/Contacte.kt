package com.example.reciclerviewdemo

class Contacte(val name:String, val phone: String){

}
